package org.example;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        double cantidad, unidad;
        String opc;

        do{
            System.out.println("Selecciona la unidad de conversion:");
            System.out.println("1) Kilómetros a millas");
            System.out.println("2) Litros a galones");
            System.out.println("3) Gramos a onzas");
            System.out.println("4) Centímetros a pulgadas");
            System.out.println("5) Salir");
            opc = scanner.nextLine();

            switch (opc){
                case "1":
                    System.out.println("Ingresa la cantidad a convertir:");
                    cantidad=scanner.nextDouble();
                    scanner.nextLine();

                    unidad= cantidad * 0.621371;
                    System.out.println("Los kilometros "+cantidad+" es igual a "+ unidad+" millas");
                    break;

                case "2":
                    System.out.println("Ingresa la cantidad a convertir:");
                    cantidad=scanner.nextDouble();
                    scanner.nextLine();

                    unidad= cantidad * 0.264172;
                    System.out.println("Los litros "+cantidad+" es igual a "+ unidad+" galones");
                    break;

                case "3":
                    System.out.println("Ingresa la cantidad a convertir:");
                    cantidad=scanner.nextDouble();
                    scanner.nextLine();

                    unidad= cantidad * 0.03527396;
                    System.out.println("Los gramos "+cantidad+" es igual a "+ unidad+" onzas");
                    break;

                case "4":
                    System.out.println("Ingresa la cantidad a convertir:");
                    cantidad=scanner.nextDouble();
                    scanner.nextLine();

                    unidad= cantidad * 0.393701;
                    System.out.println("Los centimetros "+cantidad+" es igual a "+ unidad+" pulgadas");
                    break;

                case "5":
                    System.out.println("Usted salio del menú");
                    break;

                default:
                    System.out.println("Esa opcion no existe");
                    break;
            }
        }while (!opc.equals("5"));

        scanner.close();
    }
}